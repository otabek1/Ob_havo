package otabek.io.obhavo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    public String Capitalize(String lowerCaseDayOfTheWeek){
        return lowerCaseDayOfTheWeek.substring(0,1).toUpperCase()+lowerCaseDayOfTheWeek.substring(1).toLowerCase(); }


    public String dayAdder(int numberOfdaysToadd){
        SimpleDateFormat sdf = new SimpleDateFormat("EEEE");
        Date dt = new Date();
        Calendar c = Calendar.getInstance();
        c.setTime(dt);
        c.add(Calendar.DATE, numberOfdaysToadd);
        dt = c.getTime();


        String dayOfTheWeek = sdf.format(dt);
        return Capitalize(dayOfTheWeek);

    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView cityName = findViewById(R.id.cityname);
        TextView mainTemp = findViewById(R.id.temperature);

        TextView day = findViewById(R.id.day);
        day.setText(dayAdder(0));
        TextView day1 = findViewById(R.id.day1);
        day1.setText(dayAdder(1));
        TextView day2 = findViewById(R.id.day2);
        day2.setText(dayAdder(2));
        TextView day3 = findViewById(R.id.day3);
        day3.setText(dayAdder(3));
        TextView day4 = findViewById(R.id.day4);
        day4.setText(dayAdder(4));
        TextView day5 = findViewById(R.id.day5);
        day5.setText(dayAdder(5));
        TextView day6 = findViewById(R.id.day6);
        day6.setText(dayAdder(6));


//        Log.i("TAG", dayOfTheWeek);
    }
}
